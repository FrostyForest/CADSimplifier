# FreeCAD init script of the CADSimplifier module
# (c) 2001 Juergen Riegel LGPL
